# Define a testing function for the check_cols() function
test_check_cols <- function() {
  # Test with all expected columns present and matching names
  expect_cols <- c("col1", "col2", "col3")
  cols <- c("col1", "col2", "col3")
  file_path <- "test.csv"

  test_that("All expected columns present and matching names", {
    expect_warning(check_cols(expect_cols, cols, file_path), NA)
  })

  # Test with not all expected columns present and matching names
  expect_cols <- c("col1", "col2", "col3")
  cols <- c("col1")
  file_path <- "test.csv"

  test_that("All expected columns present and matching names", {
    expect_warning(check_cols(expect_cols, cols, file_path))
  })
}