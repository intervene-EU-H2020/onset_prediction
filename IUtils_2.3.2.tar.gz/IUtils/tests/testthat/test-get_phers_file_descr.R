test_that("get_phers_file_descr works", {
  file_descr <- get_phers_file_descr()
  expect_descr <- "exposure=1999-01-01-2008-12-31-washoutend=2010-12-31-observationend=2019-01-01"
  expect_equal(file_descr, expect_descr)
})
