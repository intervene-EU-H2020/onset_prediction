test_that("read_pheno_file correct file works", {
  score_type <- c("CCI", "EDU", "PRS", "PheRS")
  get_all_possible_score_type_combs(score_type)
})
