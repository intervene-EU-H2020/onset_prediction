# test_that("run_ana_setup_file works", {
#   run_ana_setup_file("../data/test_setup.tsv")
# })
